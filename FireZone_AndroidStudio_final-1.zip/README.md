# 🔥 FireZone Battle Royale — Android Studio Project

## هيكل الملفات

```
FireZoneApp/
├── build.gradle              ← Groovy DSL (Project)
├── settings.gradle           ← Groovy DSL
├── gradle.properties         ← Properties
└── app/
    ├── build.gradle          ← Groovy DSL (Module)
    └── src/main/
        ├── AndroidManifest.xml               ← XML
        ├── java/com/firezone/game/
        │   ├── SplashActivity.java           ← Java
        │   ├── MainActivity.java             ← Java
        │   └── GameEngine.java               ← Java
        ├── res/
        │   ├── layout/activity_splash.xml    ← XML
        │   ├── values/strings.xml            ← XML
        │   ├── values/styles.xml             ← XML
        │   ├── values/colors.xml             ← XML
        │   └── drawable/ic_launcher.xml      ← XML
        └── assets/game/
            ├── index.html                    ← HTML5 + JavaScript (اللعبة)
            ├── styles.css                    ← CSS
            └── game_config.json             ← JSON
```

## اللغات المستخدمة

| اللغة | الملف | الدور |
|-------|-------|-------|
| Java | MainActivity.java | AdMob + WebView + Bridge |
| Java | SplashActivity.java | شاشة البداية |
| Java | GameEngine.java | منطق اللعبة |
| Groovy DSL | build.gradle | إعدادات البناء |
| XML | AndroidManifest.xml | إعدادات التطبيق |
| XML | res/layout/*.xml | واجهات XML |
| XML | res/values/*.xml | موارد النصوص والألوان |
| HTML5 | assets/game/index.html | محرك اللعبة كاملاً |
| JavaScript | داخل index.html | منطق اللعبة + Android Bridge |
| CSS | assets/game/styles.css | تنسيق اللعبة |
| JSON | assets/game/game_config.json | إعدادات اللعبة |

## خطوات الفتح في Android Studio

1. افتح Android Studio
2. اختر "Open an existing project"
3. اختر مجلد `FireZoneApp`
4. انتظر Gradle Sync
5. استبدل AdMob App ID في AndroidManifest.xml
6. Run ▶️

## AdMob IDs
- استبدل `ca-app-pub-XXXXXXXX` بـ ID حقيقي من حسابك
- حالياً تستخدم Test IDs تشتغل بدون حساب

## اللعبة تشتغل 100% بدون انترنت
- ملفات اللعبة في `assets/` تُحمَّل محلياً
- `WebSettings.LOAD_CACHE_ELSE_NETWORK` — offline أولاً
- الإعلانات الوحيدة تحتاج انترنت (AdMob)

## 🆕 النسخة 3D (index3d.html)

اللعبة الآن تشتغل بمحرك 3D حقيقي مبني على Three.js:
- كاميرا شخص ثالث، حركة بعصا افتراضية (يسار الشاشة) ونظر باللمس (يمين الشاشة)
- قفز، إطلاق نار بـ Raycasting حقيقي
- عوائق وأسوار 3D فـ كل خريطة
- **نظام 1000 مستوى**: الصعوبة (عدد الأعداء، سرعتهم، ضررهم، حجم الخريطة، الوقت المتاح) تتصاعد تلقائياً كل ما زاد المستوى — بدل تصميم 1000 مستوى يدوياً وهو غير عملي. التقدم يُحفظ محلياً (localStorage).
- **شخصيات مجسّمة (Humanoid)**: كل شخصية/عدو مبني من رأس + جذع + أطراف + إكسسوار مميّز حسب الدور (بندقية طويلة للقناص، كتفيات للمدافع، عباءة للمخفي...) — أشكال هندسية أصلية 100% بلا أي نسخ لتصاميم محمية. **يمكن استبدالها بنماذج glTF حقيقية بلا تعديل الكود**: فـ `CHAR_DATA` (أعلى السكريبت فـ `index3d.html`) بدّل `modelUrl` و`enemyModelUrl` لكل شخصية بمسار ملف `.glb` (مثلاً `models/wolf.glb` محطوط فـ `assets/game/models/`)، واللعبة غادي تحمّلو تلقائياً وتبدّل بيه الشكل الهندسي. بلا رابط، كتبقى الأشكال الهندسية.
- **ذكاء اصطناعي محسّن للأعداء**: خط رؤية حقيقي (`hasLineOfSight`) — الأعداء ما عادش يضربو من خلال الحيطان/العوائق، عندهم حالات تكتيكية (مطاردة / تمركز والتصويب / احتماء خلف عائق عند انخفاض الصحة)، والرصاص ديال اللاعب كيتوقف عند العوائق (بلا اختراق).
- **خريطة مصغّرة (Minimap)**: أعلى يمين الشاشة، كتوري موقع اللاعب (سهم برتقالي بيتّجاه نظره) والأعداء الأحياء (نقط حمراء) والعوائق نسبةً لحجم الخريطة الحالية.
- **3 بيئات متبدّلة حسب المستوى**: غابة 🌲 / صحراء 🏜️ / مدينة 🏙️ — تتغيّر ألوان الأرض والسماء وارتفاع العوائق (مباني أطول فـ المدينة) تلقائياً كل ما تقدّم اللاعب فـ المستويات.

### ⚠️ خطوة ضرورية لجعلها Offline 100%
الملف يحمّل مكتبة Three.js حالياً من رابط خارجي (CDN):
```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
```
لأن حجمها كبير ويحتاج تحميلها يدوياً مرة واحدة. الخطوات:
1. حمّل الملف من: `https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js`
2. ضعه فـ: `app/src/main/assets/game/three.min.js`
3. فـ `index3d.html` بدّل السطر لـ:
   ```html
   <script src="three.min.js"></script>
   ```
بهاذ الشكل اللعبة كاملة (بلا الإعلانات) غادي تخدم بلا انترنت.

### الخريطة الأصلية (2D)
محفوظة فـ `index_2d_backup.html` إيلا بغيتي ترجع ليها أو تقارن.

### الخطوات الجاية (خارج نطاق هاد التحديث)
- تصميم نماذج 3D حقيقية (.glb) فـ برنامج خارجي (Blender أو شراء أصول جاهزة) — البنية جاهزة لاستقبالها مباشرة (راجع فقرة الشخصيات أعلاه)
- واجهة Native Ad كاملة (المعرّف محمّل حالياً بلا عرض)
- أصوات وتأثيرات (SFX) للأسلحة والإصابات

