package com.firezone.game;

// ============================================
// GameEngine.java — Java
// محرك اللعبة: منطق الجلسة، الإحصائيات، SharedPrefs
// ============================================

import android.content.Context;
import android.content.SharedPreferences;

public class GameEngine {

    private static final String PREFS_NAME = "firezone_prefs";
    private final SharedPreferences prefs;

    // إحصائيات الجلسة
    private int sessionKills = 0;
    private int sessionShots = 0;
    private int sessionHits  = 0;
    private long sessionStart;

    public GameEngine(Context context) {
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public void startSession() {
        sessionKills = 0;
        sessionShots = 0;
        sessionHits  = 0;
        sessionStart = System.currentTimeMillis();
    }

    public void recordKill()     { sessionKills++; }
    public void recordShot()     { sessionShots++; }
    public void recordHit()      { sessionHits++;  }

    public int getKills()        { return sessionKills; }
    public int getAccuracy()     { return sessionShots > 0 ? (sessionHits * 100 / sessionShots) : 0; }
    public long getSessionTime() { return (System.currentTimeMillis() - sessionStart) / 1000; }

    public void saveHighScore() {
        int best = prefs.getInt("best_kills", 0);
        if (sessionKills > best) {
            prefs.edit().putInt("best_kills", sessionKills).apply();
        }
    }

    public int getBestKills()     { return prefs.getInt("best_kills", 0); }
    public String getPlayerName() { return prefs.getString("player_name", "لاعب"); }
    public void setPlayerName(String name) {
        prefs.edit().putString("player_name", name).apply();
    }
}
