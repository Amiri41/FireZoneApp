package com.firezone.game;

// ============================================
// SplashActivity.java — Java
// شاشة البداية + تهيئة AdMob
// ============================================

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.appopen.AppOpenAd;

public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_MIN_DELAY = 2500; // أقل مدة عرض شعار اللعبة
    private static final int SPLASH_MAX_WAIT  = 4000; // أقصى مدة انتظار تحميل الإعلان
    private static final String APP_OPEN_ID   = "ca-app-pub-5606142224218961/1562471013";

    private AppOpenAd appOpenAd;
    private boolean navigated = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setContentView(R.layout.activity_splash);

        // تهيئة AdMob
        MobileAds.initialize(this, initializationStatus -> loadAppOpenAd());

        // بعد أقل مدة، جرّب عرض إعلان فتح التطبيق إذا كان جاهز، وإلا انتقل مباشرة
        new Handler(Looper.getMainLooper()).postDelayed(this::showAdOrProceed, SPLASH_MIN_DELAY);
        // ضمان عدم بقاء المستخدم عالقاً إذا تأخر تحميل الإعلان
        new Handler(Looper.getMainLooper()).postDelayed(this::goToGame, SPLASH_MAX_WAIT);
    }

    private void loadAppOpenAd() {
        AdRequest request = new AdRequest.Builder().build();
        AppOpenAd.load(this, APP_OPEN_ID, request,
            new AppOpenAd.AppOpenAdLoadCallback() {
                @Override
                public void onAdLoaded(AppOpenAd ad) {
                    appOpenAd = ad;
                }
                @Override
                public void onAdFailedToLoad(com.google.android.gms.ads.LoadAdError error) {
                    appOpenAd = null;
                }
            });
    }

    private void showAdOrProceed() {
        if (navigated) return;
        if (appOpenAd != null) {
            appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    goToGame();
                }
                @Override
                public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                    goToGame();
                }
            });
            appOpenAd.show(this);
        } else {
            goToGame();
        }
    }

    private void goToGame() {
        if (navigated) return;
        navigated = true;
        startActivity(new Intent(SplashActivity.this, MainActivity.class));
        finish();
    }
}
