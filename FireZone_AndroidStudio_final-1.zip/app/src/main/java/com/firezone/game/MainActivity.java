package com.firezone.game;

// ============================================
// MainActivity.java — Java
// النشاط الرئيسي: WebView + AdMob + Vibration
// ============================================

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.AdLoader;

public class MainActivity extends AppCompatActivity {

    // ---- Views ----
    private WebView gameWebView;
    private AdView bannerAdView;
    private LinearLayout rootLayout;

    // ---- AdMob IDs (الحقيقية من حساب: ca-app-pub-5606142224218961) ----
    private static final String BANNER_ID               = "ca-app-pub-5606142224218961/9492931927";
    private static final String REWARDED_ID              = "ca-app-pub-5606142224218961/8179850251";
    private static final String REWARDED_INTERSTITIAL_ID = "ca-app-pub-5606142224218961/3290450268"; // بديل الإعلان البيني
    private static final String NATIVE_ID                = "ca-app-pub-5606142224218961/5393869422"; // محمّل فقط، بلا واجهة بعد

    // ---- Ads ----
    private RewardedInterstitialAd mRewardedInterstitialAd;
    private RewardedAd mRewardedAd;
    private NativeAd mNativeAd;

    // ---- Vibrator ----
    private Vibrator vibrator;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ملء الشاشة الكاملة
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // إخفاء شريط النظام (Immersive Mode)
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );

        // Layout رئيسي
        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(0xFF0A0A0F);

        // WebView للعبة
        gameWebView = new WebView(this);
        FrameLayout.LayoutParams webParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            0
        );
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0, 1f
        );
        gameWebView.setLayoutParams(wlp);
        setupWebView();

        // Banner Ad في الأسفل
        bannerAdView = new AdView(this);
        bannerAdView.setAdSize(AdSize.BANNER);
        bannerAdView.setAdUnitId(BANNER_ID);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        bannerAdView.setLayoutParams(blp);
        bannerAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() { bannerAdView.setVisibility(View.VISIBLE); }
        });

        rootLayout.addView(gameWebView);
        rootLayout.addView(bannerAdView);
        setContentView(rootLayout);

        // تحميل الإعلانات
        loadBannerAd();
        loadRewardedInterstitialAd();
        loadRewardedAd();
        loadNativeAd();

        // Vibrator
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        // تحميل اللعبة من Assets (بدون انترنت — ما عدا مكتبة Three.js التي تحتاج تحميلها محلياً، راجع README)
        gameWebView.loadUrl("file:///android_asset/game/index3d.html");
    }

    // ============================================
    // إعداد WebView
    // ============================================
    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings settings = gameWebView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK); // offline أولاً
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setRenderPriority(WebSettings.RenderPriority.HIGH);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        // Hardware acceleration
        gameWebView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        // JavaScript Bridge (Java ↔ JS)
        gameWebView.addJavascriptInterface(new AndroidBridge(), "Android");

        gameWebView.setWebChromeClient(new WebChromeClient());
        gameWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // كل الروابط تبقى داخل WebView
                return false;
            }
        });
    }

    // ============================================
    // Android Bridge — Java ↔ JavaScript
    // ============================================
    private class AndroidBridge {

        // عرض إعلان بين الجولات من JS (Rewarded Interstitial بديل الـ Interstitial العادي)
        @JavascriptInterface
        public void showInterstitialAd() {
            runOnUiThread(() -> {
                if (mRewardedInterstitialAd != null) {
                    mRewardedInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                        @Override
                        public void onAdDismissedFullScreenContent() {
                            mRewardedInterstitialAd = null;
                            loadRewardedInterstitialAd(); // تحميل الإعلان التالي
                            gameWebView.post(() ->
                                gameWebView.evaluateJavascript("onAdClosed();", null)
                            );
                        }
                        @Override
                        public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError adError) {
                            mRewardedInterstitialAd = null;
                            gameWebView.post(() ->
                                gameWebView.evaluateJavascript("onAdClosed();", null)
                            );
                        }
                    });
                    mRewardedInterstitialAd.show(MainActivity.this, rewardItem -> {
                        // لا حاجة لمعالجة خاصة بالمكافأة هنا؛ هذا استخدام كـ إعلان بيني فقط
                    });
                } else {
                    // لا يوجد إعلان — أكمل اللعبة مباشرة
                    gameWebView.post(() ->
                        gameWebView.evaluateJavascript("onAdClosed();", null)
                    );
                }
            });
        }

        // عرض إعلان Rewarded من JS
        @JavascriptInterface
        public void showRewardedAd(String rewardType) {
            runOnUiThread(() -> {
                if (mRewardedAd != null) {
                    mRewardedAd.show(MainActivity.this, rewardItem -> {
                        // المكافأة
                        gameWebView.post(() ->
                            gameWebView.evaluateJavascript(
                                "onRewardEarned('" + rewardType + "');", null)
                        );
                    });
                }
            });
        }

        // اهتزاز الهاتف
        @JavascriptInterface
        public void vibrate(int ms) {
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(ms,
                        VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vibrator.vibrate(ms);
                }
            }
        }

        // حفظ النقاط
        @JavascriptInterface
        public void saveScore(int kills, int accuracy) {
            getSharedPreferences("firezone_prefs", MODE_PRIVATE)
                .edit()
                .putInt("best_kills", kills)
                .putInt("best_accuracy", accuracy)
                .apply();
        }

        // قراءة أفضل نقاط
        @JavascriptInterface
        public int getBestKills() {
            return getSharedPreferences("firezone_prefs", MODE_PRIVATE)
                .getInt("best_kills", 0);
        }

        // حفظ اسم اللاعب
        @JavascriptInterface
        public void savePlayerName(String name) {
            getSharedPreferences("firezone_prefs", MODE_PRIVATE)
                .edit().putString("player_name", name).apply();
        }

        // قراءة اسم اللاعب
        @JavascriptInterface
        public String getPlayerName() {
            return getSharedPreferences("firezone_prefs", MODE_PRIVATE)
                .getString("player_name", "لاعب");
        }
    }

    // ============================================
    // AdMob — Banner
    // ============================================
    private void loadBannerAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        bannerAdView.loadAd(adRequest);
    }

    // ============================================
    // AdMob — Rewarded Interstitial (بديل الإعلان البيني العادي)
    // ============================================
    private void loadRewardedInterstitialAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        RewardedInterstitialAd.load(this, REWARDED_INTERSTITIAL_ID, adRequest,
            new RewardedInterstitialAdLoadCallback() {
                @Override
                public void onAdLoaded(RewardedInterstitialAd ad) {
                    mRewardedInterstitialAd = ad;
                }
                @Override
                public void onAdFailedToLoad(LoadAdError error) {
                    mRewardedInterstitialAd = null;
                }
            });
    }

    // ============================================
    // AdMob — Native Advanced (تحميل فقط، بدون واجهة عرض بعد)
    // ============================================
    private void loadNativeAd() {
        AdLoader adLoader = new AdLoader.Builder(this, NATIVE_ID)
            .forNativeAd(nativeAd -> {
                if (mNativeAd != null) mNativeAd.destroy();
                mNativeAd = nativeAd;
                // TODO: عند تصميم واجهة NativeAdView خاصة، اعرض mNativeAd هنا
            })
            .withAdListener(new AdListener() {
                @Override
                public void onAdFailedToLoad(LoadAdError error) {
                    mNativeAd = null;
                }
            })
            .build();
        adLoader.loadAd(new AdRequest.Builder().build());
    }

    // ============================================
    // AdMob — Rewarded
    // ============================================
    private void loadRewardedAd() {
        AdRequest adRequest = new AdRequest.Builder().build();
        RewardedAd.load(this, REWARDED_ID, adRequest,
            new RewardedAdLoadCallback() {
                @Override
                public void onAdLoaded(RewardedAd ad) {
                    mRewardedAd = ad;
                }
                @Override
                public void onAdFailedToLoad(LoadAdError error) {
                    mRewardedAd = null;
                }
            });
    }

    // ============================================
    // دورة حياة Activity
    // ============================================
    @Override
    protected void onResume() {
        super.onResume();
        if (bannerAdView != null) bannerAdView.resume();
        if (gameWebView != null) gameWebView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (bannerAdView != null) bannerAdView.pause();
        if (gameWebView != null) gameWebView.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (bannerAdView != null) bannerAdView.destroy();
        if (gameWebView != null) gameWebView.destroy();
    }

    @Override
    public void onBackPressed() {
        // إيقاف مؤقت بدلاً من الخروج
        gameWebView.evaluateJavascript("if(typeof togglePauseFromAndroid==='function')togglePauseFromAndroid();", null);
    }
}
